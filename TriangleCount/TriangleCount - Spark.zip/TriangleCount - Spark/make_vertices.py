f = open("email-Eu-vertices.txt","w")

for i in range(1005):
	f.write(str(i)+"\n")
f.close()
